"""
build_sepsis_mimic3_bq.py

Builds a multi-horizon sepsis prediction dataset from MIMIC-III notes
using BigQuery. For each ICU stay:
- Input: free-text notes within first 24h of ICU admission
- Outputs: binary labels for sepsis onset in (t_cutoff, t_cutoff + h]
  for horizons h ∈ {6, 12, 24, 48} hours.
- Meta: subject_id, hadm_id, icustay_id, t_cutoff, target="sepsis"

Requires:
  - google-cloud-bigquery
  - pandas
  - db-dtypes (for BigQuery → pandas integration)
  - an LLM client (Gemini or OpenAI-style), see LLM section below.
"""

import json
import os
import time
import re
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

from datetime import datetime

import pandas as pd
from google.cloud import bigquery
from tqdm import tqdm

# If you want to use Gemini:
try:
    import google.generativeai as genai
    _HAS_GENAI = True
except ImportError:
    _HAS_GENAI = False

# -------------------------
# CONFIG
# -------------------------

GCP_PROJECT_ID = "charged-sector-450700-m8"
OBS_HOURS = 24
HORIZONS = [6, 12, 24, 48]

# BigQuery table paths
ICUSTAYS_TABLE = "physionet-data.mimiciii_clinical.icustays"
ADMISSIONS_TABLE = "physionet-data.mimiciii_clinical.admissions"
PATIENTS_TABLE = "physionet-data.mimiciii_clinical.patients"
NOTEEVENTS_TABLE = "physionet-data.mimiciii_notes.noteevents"

OUTPUT_JSONL = "sepsis_multihorizon_24h_notes_mimic3_bq_llm.jsonl"

# LLM CONFIG
# ==========
# For Gemini: set GEMINI_API_KEY in your environment and use MODEL_NAME below
GEMINI_MODEL_NAME = "gemini-2.5-flash"  # or gemini-1.5-pro if you want
LLM_MAX_CHARS_PER_ICU_STAY = 12000      # truncate long timelines for context
LLM_SLEEP_BETWEEN_CALLS = 0.4           # simple rate limiting


# -------------------------
# UTILITIES
# -------------------------

def get_bq_client() -> bigquery.Client:
    """Create a BigQuery client using Application Default Credentials."""
    return bigquery.Client(project=GCP_PROJECT_ID)


# -------------------------
# LLM HELPER (GEMINI OR OTHER)
# -------------------------

def init_gemini_client():
    """
    Initialize Gemini client from GEMINI_API_KEY env var.

    If you want to swap in a different LLM, replace this + call_llm_for_onset().
    """
    if not _HAS_GENAI:
        raise RuntimeError(
            "google-generativeai is not installed. Install with:\n"
            "  pip install google-generativeai"
        )
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not set in environment. "
            "Export GEMINI_API_KEY=<your_key> before running."
        )
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(GEMINI_MODEL_NAME)


def call_llm_for_onset(model, timeline_text: str) -> Optional[datetime]:
    """
    Call the LLM (Gemini by default) to extract earliest sepsis onset timestamp.

    Returns:
        datetime or None
    """
    prompt = f"""
You are assisting with a retrospective ICU research study on sepsis.

You are given a time-ordered timeline of ICU clinical notes for a single ICU stay.
Each note line begins with a timestamp in square brackets, followed by a category,
then free text. Example:

  [2114-01-01 08:15:00] (Nursing) ...
  [2114-01-01 12:30:00] (Physician) ...

IMPORTANT CONTEXT:
- You may be given only a PARTIAL timeline (not all notes).
- You must base your answer **only** on what is shown.
- If you do not see a **clear, explicit** clinician diagnosis of sepsis or septic shock
  in the provided text, you must say that there is no documented onset.

TASK:
1. Read the entire timeline.
2. Determine the earliest time at which a clinician clearly documents
   that the patient has **sepsis** or **septic shock** (not "rule out sepsis", not just "concern").
3. If such documentation exists, set onset to the timestamp of that note (as given
   in the square brackets, e.g., "2114-01-01 08:15:00").
4. If no definite sepsis or septic shock diagnosis appears in the timeline,
   set onset to null.

RESPONSE FORMAT:
Respond with a single line of JSON and NOTHING ELSE.

EITHER:
  {{ "onset": "YYYY-MM-DD HH:MM:SS" }}

OR:
  {{ "onset": null }}

Do NOT add explanations, comments, or any other keys.

TIMELINE:
{timeline_text}
""".strip()

    try:
        response = model.generate_content(prompt)
        raw = (response.text or "").strip()
    except Exception as e:
        print(f"[LLM ERROR] {e}")
        return None

    # Try to extract JSON object from the response
    m = re.search(r"\{.*\}", raw, flags=re.DOTALL)
    if not m:
        print(f"[LLM PARSE WARNING] No JSON object found in LLM output: {raw!r}")
        return None

    json_str = m.group(0)
    try:
        data = json.loads(json_str)
    except Exception as e:
        print(f"[LLM PARSE WARNING] JSON decode error: {e} | raw={raw!r}")
        return None

    onset_val = data.get("onset", None)
    if onset_val is None:
        # this is the 'no sepsis documented' case
        return None

    # Strip quotes/whitespace just in case
    onset_val = str(onset_val).strip().strip('"').strip("'")

    # Parse as datetime
    dt = pd.to_datetime(onset_val, errors="coerce")
    if pd.isna(dt):
        print(f"[LLM PARSE WARNING] Could not parse onset timestamp: {onset_val!r} | raw={raw!r}")
        return None

    return dt.to_pydatetime()

# -------------------------
# LOAD ICU COHORT
# -------------------------

def load_cohort_bq(client: bigquery.Client) -> pd.DataFrame:
    """
    Load adult ICU cohort from MIMIC-III via BigQuery.
    - Age >= 18
    - ICU LOS >= OBS_HOURS
    """
    print("Loading ICU cohort from MIMIC-III BigQuery...")

    query = f"""
    WITH base AS (
      SELECT
        icu.subject_id,
        icu.hadm_id,
        icu.icustay_id,
        DATETIME(icu.intime) AS intime,
        DATETIME(icu.outtime) AS outtime,
        DATETIME_DIFF(DATETIME(icu.outtime), DATETIME(icu.intime), HOUR) AS los_hrs,
        DATETIME(a.admittime) AS admittime,
        DATETIME(a.dischtime) AS dischtime,
        p.gender,
        -- approximate age at admission
        EXTRACT(YEAR FROM a.admittime) - EXTRACT(YEAR FROM p.dob) AS age_raw
      FROM `{ICUSTAYS_TABLE}` AS icu
      JOIN `{ADMISSIONS_TABLE}` AS a
        ON icu.subject_id = a.subject_id
       AND icu.hadm_id = a.hadm_id
      JOIN `{PATIENTS_TABLE}` AS p
        ON icu.subject_id = p.subject_id
    )
    SELECT
      subject_id,
      hadm_id,
      icustay_id,
      intime,
      outtime,
      los_hrs,
      admittime,
      dischtime,
      gender,
      -- cap age at 91 as per MIMIC convention
      CASE WHEN age_raw > 89 THEN 91 ELSE age_raw END AS age
    FROM base
    WHERE age_raw >= 18
      AND los_hrs >= {OBS_HOURS}
    """

    df = client.query(query).to_dataframe()
    print(f"Cohort size: {len(df)} ICU stays")
    return df


# -------------------------
# STEP 2: LOAD NOTES FOR COHORT
# -------------------------

def load_notes_for_cohort_bq(client: bigquery.Client) -> pd.DataFrame:
    """
    Load notes for the ICU cohort, for the *entire* ICU stay.
    We will later restrict to first 24h in Python (for inputs),
    but we use the full stay for LLM-based sepsis onset detection.

    We exclude notes with iserror = 1.
    """
    print("Loading notes for cohort (entire ICU stay)...")

    query = f"""
    WITH cohort AS (
      SELECT
        icu.subject_id,
        icu.hadm_id,
        icu.icustay_id,
        DATETIME(icu.intime) AS intime,
        DATETIME(icu.outtime) AS outtime,
        DATETIME_DIFF(DATETIME(icu.outtime), DATETIME(icu.intime), HOUR) AS los_hrs,
        DATETIME(a.admittime) AS admittime,
        DATETIME(a.dischtime) AS dischtime,
        p.gender,
        EXTRACT(YEAR FROM a.admittime) - EXTRACT(YEAR FROM p.dob) AS age_raw
      FROM `{ICUSTAYS_TABLE}` AS icu
      JOIN `{ADMISSIONS_TABLE}` AS a
        ON icu.subject_id = a.subject_id
       AND icu.hadm_id = a.hadm_id
      JOIN `{PATIENTS_TABLE}` AS p
        ON icu.subject_id = p.subject_id
    ),
    adult_long AS (
      SELECT
        subject_id,
        hadm_id,
        icustay_id,
        intime,
        outtime,
        admittime,
        dischtime,
        gender,
        CASE WHEN age_raw > 89 THEN 91 ELSE age_raw END AS age,
        los_hrs
      FROM cohort
      WHERE age_raw >= 18
        AND los_hrs >= {OBS_HOURS}
    )
    SELECT
      c.subject_id,
      c.hadm_id,
      c.icustay_id,
      c.intime,
      c.outtime,
      n.charttime,
      n.category,
      n.text
    FROM adult_long AS c
    JOIN `{NOTEEVENTS_TABLE}` AS n
      ON c.subject_id = n.subject_id
     AND c.hadm_id = n.hadm_id
    WHERE (n.iserror IS NULL OR n.iserror = 0)
      AND n.charttime BETWEEN c.intime AND c.outtime
    """

    df_notes = client.query(query).to_dataframe()
    print("Notes shape:", df_notes.shape)
    print(df_notes.head())
    print(f"Loaded {len(df_notes)} notes")
    return df_notes


# -------------------------
# STEP 3: SEPSIS ONSET FROM NOTES VIA LLM
# -------------------------

def format_single_note_row(row: pd.Series) -> str:
    """Format a single note row into a line for the timeline / prompt."""
    ts = row["charttime"]
    cat = row.get("category", "")
    txt = row.get("text", "") or ""
    txt = " ".join(str(txt).split())  # Collapse whitespace
    return f"[{ts}] ({cat}) {txt}"


def compute_sepsis_onset_with_llm(df_notes: pd.DataFrame) -> pd.DataFrame:
    """
    Use an LLM (Gemini by default) to infer earliest sepsis/septic shock onset
    per ICU stay, purely from the clinical notes.
    """
    print("Computing sepsis onset from notes via LLM...")

    if df_notes.empty:
        return pd.DataFrame(columns=["icustay_id", "sepsis_onset_time"])

    model = init_gemini_client()
    print("Gemini client initialized.")

    df = df_notes.copy()
    df["charttime"] = pd.to_datetime(df["charttime"])

    onset_rows = []

    grouped = df.groupby("icustay_id", sort=False)
    total_stays = len(grouped)
    print(f"Running LLM onset extraction for {total_stays} ICU stays...")

    for idx, (icustay_id, g) in tqdm(enumerate(grouped, start=1)):
        # LIMIT for prototyping
        if idx > 1000:
            print(f"Reached MAX_STAYS_FOR_LLM={MAX_STAYS_FOR_LLM}, stopping early.")
            break

        g = g.sort_values("charttime")

        # Build timeline text
        lines = [format_single_note_row(r) for _, r in g.iterrows()]
        timeline = "\n".join(lines)

        # Truncate to stay within context length
        if len(timeline) > LLM_MAX_CHARS_PER_ICU_STAY:
            timeline = timeline[:LLM_MAX_CHARS_PER_ICU_STAY]

        onset_dt = None
        for attempt in range(3):
            try:
                onset_dt = call_llm_for_onset(model, timeline)
                break  # success (even if None)
            except Exception as e:
                print(f"[LLM ERROR] icustay_id={icustay_id}, attempt={attempt+1}: {e}")
                time.sleep(2.0 * (attempt + 1))  # simple backoff

        if onset_dt is None:
            # Either genuinely no sepsis documented, or we failed
            pass

        onset_rows.append(
            {
                "icustay_id": icustay_id,
                "sepsis_onset_time": onset_dt
            }
        )

        if idx % 50 == 0:
            print(f"  Processed {idx}/{total_stays} ICU stays...")

        time.sleep(LLM_SLEEP_BETWEEN_CALLS)

    onset_df = pd.DataFrame(onset_rows)
    print("Example LLM onset rows:")
    print(onset_df.head())
    return onset_df

# -------------------------
# STEP 4: BUILD 24H INPUT TEXT (unchanged)
# -------------------------

def build_input_text_24h(df_notes: pd.DataFrame, cohort: pd.DataFrame) -> pd.DataFrame:
    """
    Build input text for first 24h after ICU admission.
    - Restrict notes: intime <= charttime <= intime + OBS_HOURS
    - Group by icustay_id
    - Produce a single string per icustay_id
    """
    print("Building input text from first 24h notes...")

    if df_notes.empty:
        print("No notes available at all; will fall back to 'No notes available.'")
        return pd.DataFrame(columns=["icustay_id", "input_text"])

    # Merge intime by icustay_id
    cohort_min = cohort[["icustay_id", "intime"]].drop_duplicates()
    notes = df_notes.merge(cohort_min, on="icustay_id", how="left", suffixes=("", "_icu"))

    # Compute 24h cutoff
    notes["cutoff_24h"] = notes["intime"] + pd.to_timedelta(OBS_HOURS, unit="h")

    # Filter to first 24h
    mask_24h = (notes["charttime"] >= notes["intime"]) & (
        notes["charttime"] <= notes["cutoff_24h"]
    )
    notes_24h = notes[mask_24h].copy()

    if notes_24h.empty:
        print("No notes within first 24h for any ICU stay.")
        return pd.DataFrame(columns=["icustay_id", "input_text"])

    notes_24h = notes_24h.sort_values(["icustay_id", "charttime"])

    def format_group(group: pd.DataFrame) -> str:
        lines = [format_single_note_row(r) for _, r in group.iterrows()]
        body = "\n".join(lines)
        header = (
            "You are a clinical model. Below are notes up to 24 hours after ICU admission.\n\n"
        )
        return header + body

    df_inputs = (
        notes_24h.groupby("icustay_id", as_index=False)
        .apply(lambda g: pd.Series({"input_text": format_group(g)}))
    )

    print(df_inputs.head())
    return df_inputs[["icustay_id", "input_text"]]


# -------------------------
# STEP 5: MULTI-HORIZON LABELS (unchanged logic)
# -------------------------

def compute_labels_multi_horizon(
    cohort: pd.DataFrame,
    onset_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    For each ICU stay, compute multi-horizon sepsis labels.
    - t_cutoff = intime + OBS_HOURS
    - If sepsis_onset_time in (t_cutoff, t_cutoff + h] => label h = 1
    - Else 0
    - Accumulate forward (if h12=1 => h24=h48=1)
    """
    print("Computing multi-horizon labels...")

    df = cohort[["icustay_id", "intime"]].copy()
    df = df.merge(onset_df, on="icustay_id", how="left")

    # cutoff time
    df["t_cutoff"] = df["intime"] + pd.to_timedelta(OBS_HOURS, unit="h")

    # default labels
    for h in HORIZONS:
        df[f"h{h}"] = 0

    # compute offset hours where sepsis onset exists
    has_onset = df["sepsis_onset_time"].notna()

    df.loc[has_onset, "offset_hours"] = (
        (pd.to_datetime(df.loc[has_onset, "sepsis_onset_time"]) - df.loc[has_onset, "t_cutoff"])
        .dt.total_seconds()
        / 3600.0
    )

    for idx, row in df[has_onset].iterrows():
        offset = row["offset_hours"]
        if offset is None or pd.isna(offset):
            continue
        if offset <= 0 or offset > max(HORIZONS):
            continue
        for h in HORIZONS:
            if offset <= h:
                df.at[idx, f"h{h}"] = 1

    print(df[["icustay_id", "sepsis_onset_time"] + [f"h{h}" for h in HORIZONS]].head())
    return df[["icustay_id", "t_cutoff"] + [f"h{h}" for h in HORIZONS]]


# -------------------------
# STEP 6: ASSEMBLE FINAL DATASET & WRITE JSONL
# -------------------------

@dataclass
class ExampleRecord:
    input: str
    output: Dict[str, Any]
    meta: Dict[str, Any]


def build_final_dataset(
    cohort: pd.DataFrame,
    inputs_df: pd.DataFrame,
    labels_df: pd.DataFrame,
    target: str = "sepsis",
) -> List[ExampleRecord]:
    """
    Merge cohort, input_text, and labels into final example records.
    """
    print("Assembling final dataset...")

    df = cohort[["subject_id", "hadm_id", "icustay_id"]].copy()

    # merge input_text
    df = df.merge(inputs_df, on="icustay_id", how="left")

    # fill no-note stays with default text
    default_input = (
        "You are a clinical model. Below are notes up to 24 hours after ICU admission.\n\n"
        "No notes available."
    )
    df["input_text"] = df["input_text"].fillna(default_input)

    # merge labels
    df = df.merge(labels_df, on="icustay_id", how="left")

    # any missing label rows => fill 0
    for h in HORIZONS:
        col = f"h{h}"
        df[col] = df[col].fillna(0).astype(int)

    df["t_cutoff"] = df["t_cutoff"].fillna(
        df["icustay_id"].map(
            cohort.set_index("icustay_id")["intime"]
        ) + pd.to_timedelta(OBS_HOURS, unit="h")
    )

    examples: List[ExampleRecord] = []
    for _, row in df.iterrows():
        output = {f"h{h}": int(row[f"h{h}"]) for h in HORIZONS}
        output["rationale"] = ""  # placeholder for future

        meta = {
            "icustay_id": int(row["icustay_id"]),
            "subject_id": int(row["subject_id"]),
            "hadm_id": int(row["hadm_id"]),
            "t_cutoff": OBS_HOURS,
            "target": target,
        }

        examples.append(
            ExampleRecord(
                input=row["input_text"],
                output=output,
                meta=meta,
            )
        )

    print(f"Built {len(examples)} examples")
    return examples


def write_jsonl(examples: List[ExampleRecord], output_path: str) -> None:
    """
    Write examples to JSONL in the desired format.
    """
    print(f"Writing JSONL dataset to {output_path}...")
    with open(output_path, "w", encoding="utf-8") as f:
        for ex in examples:
            rec = {
                "input": ex.input,
                "output": ex.output,
                "meta": ex.meta,
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"Wrote {len(examples)} records to {output_path}")


# -------------------------
# MAIN
# -------------------------

def main():
    client = get_bq_client()

    # 1) Cohort
    cohort = load_cohort_bq(client)

    # 2) Notes (entire ICU stay)
    df_notes = load_notes_for_cohort_bq(client)

    # 3) Sepsis onset from notes via LLM
    onset_df = compute_sepsis_onset_with_llm(df_notes)

    # 4) Input text (first 24h)
    inputs_df = build_input_text_24h(df_notes, cohort)

    # 5) Multi-horizon labels
    labels_df = compute_labels_multi_horizon(cohort, onset_df)

    # 6) Final examples
    examples = build_final_dataset(cohort, inputs_df, labels_df, target="sepsis")

    # 7) Write JSONL
    write_jsonl(examples, OUTPUT_JSONL)


if __name__ == "__main__":
    main()
