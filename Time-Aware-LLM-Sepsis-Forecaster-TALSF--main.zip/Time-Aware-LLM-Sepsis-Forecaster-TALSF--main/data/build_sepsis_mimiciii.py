"""
build_sepsis_mimic3_bq.py

Builds a multi-horizon sepsis prediction dataset from MIMIC-III notes
using BigQuery. For each ICU stay:
- Input: free-text notes within first 24h of ICU admission
- Outputs: binary labels for sepsis onset in (t_cutoff, t_cutoff + h]
  for horizons h ∈ {6, 12, 24, 48} hours.
- Meta: subject_id, hadm_id, icustay_id, t_cutoff, target="sepsis"

Requires:
  - google-cloud-bigquery
  - pandas
  - db-dtypes (for BigQuery → pandas integration)
"""

import json
from dataclasses import dataclass
from typing import List, Dict, Any
import re

import pandas as pd
from google.cloud import bigquery

# -------------------------
# CONFIG
# -------------------------

GCP_PROJECT_ID  = "charged-sector-450700-m8"
OBS_HOURS = 24
HORIZONS = [6, 12, 24, 48]

# BigQuery table paths
ICUSTAYS_TABLE = "physionet-data.mimiciii_clinical.icustays"
ADMISSIONS_TABLE = "physionet-data.mimiciii_clinical.admissions"
PATIENTS_TABLE = "physionet-data.mimiciii_clinical.patients"
NOTEEVENTS_TABLE = "physionet-data.mimiciii_notes.noteevents"

OUTPUT_JSONL = "sepsis_multihorizon_24h_notes_mimic3_bq.jsonl"

# -------------------------
# UTILITIES
# -------------------------

def get_bq_client() -> bigquery.Client:
    """Create a BigQuery client using Application Default Credentials."""
    return bigquery.Client(project=GCP_PROJECT_ID)


# -------------------------
# STEP 1: LOAD ICU COHORT
# -------------------------

def load_cohort_bq(client: bigquery.Client) -> pd.DataFrame:
    """
    Load adult ICU cohort from MIMIC-III via BigQuery.
    - Age >= 18
    - ICU LOS >= OBS_HOURS
    """
    print("Loading ICU cohort from MIMIC-III BigQuery...")

    query = f"""
    WITH base AS (
      SELECT
        icu.subject_id,
        icu.hadm_id,
        icu.icustay_id,
        DATETIME(icu.intime) AS intime,
        DATETIME(icu.outtime) AS outtime,
        DATETIME_DIFF(DATETIME(icu.outtime), DATETIME(icu.intime), HOUR) AS los_hrs,
        DATETIME(a.admittime) AS admittime,
        DATETIME(a.dischtime) AS dischtime,
        p.gender,
        -- approximate age at admission
        EXTRACT(YEAR FROM a.admittime) - EXTRACT(YEAR FROM p.dob) AS age_raw
      FROM `{ICUSTAYS_TABLE}` AS icu
      JOIN `{ADMISSIONS_TABLE}` AS a
        ON icu.subject_id = a.subject_id
       AND icu.hadm_id = a.hadm_id
      JOIN `{PATIENTS_TABLE}` AS p
        ON icu.subject_id = p.subject_id
    )
    SELECT
      subject_id,
      hadm_id,
      icustay_id,
      intime,
      outtime,
      los_hrs,
      admittime,
      dischtime,
      gender,
      -- cap age at 91 as per MIMIC convention
      CASE WHEN age_raw > 89 THEN 91 ELSE age_raw END AS age
    FROM base
    WHERE age_raw >= 18
      AND los_hrs >= {OBS_HOURS}
    """

    df = client.query(query).to_dataframe()
    print(f"Cohort size: {len(df)} ICU stays")
    return df


# -------------------------
# STEP 2: LOAD NOTES FOR COHORT
# -------------------------

def load_notes_for_cohort_bq(client: bigquery.Client) -> pd.DataFrame:
    """
    Load notes for the ICU cohort, for the *entire* ICU stay.
    We will later restrict to first 24h in Python.

    We exclude notes with iserror = 1.
    """
    print("Loading notes for cohort (entire ICU stay)...")

    query = f"""
    WITH cohort AS (
      SELECT
        icu.subject_id,
        icu.hadm_id,
        icu.icustay_id,
        DATETIME(icu.intime) AS intime,
        DATETIME(icu.outtime) AS outtime,
        DATETIME_DIFF(DATETIME(icu.outtime), DATETIME(icu.intime), HOUR) AS los_hrs,
        DATETIME(a.admittime) AS admittime,
        DATETIME(a.dischtime) AS dischtime,
        p.gender,
        EXTRACT(YEAR FROM a.admittime) - EXTRACT(YEAR FROM p.dob) AS age_raw
      FROM `{ICUSTAYS_TABLE}` AS icu
      JOIN `{ADMISSIONS_TABLE}` AS a
        ON icu.subject_id = a.subject_id
       AND icu.hadm_id = a.hadm_id
      JOIN `{PATIENTS_TABLE}` AS p
        ON icu.subject_id = p.subject_id
    ),
    adult_long AS (
      SELECT
        subject_id,
        hadm_id,
        icustay_id,
        intime,
        outtime,
        admittime,
        dischtime,
        gender,
        CASE WHEN age_raw > 89 THEN 91 ELSE age_raw END AS age,
        los_hrs
      FROM cohort
      WHERE age_raw >= 18
        AND los_hrs >= {OBS_HOURS}
    )
    SELECT
      c.subject_id,
      c.hadm_id,
      c.icustay_id,
      c.intime,
      c.outtime,
      n.charttime,
      n.category,
      n.text
    FROM adult_long AS c
    JOIN `{NOTEEVENTS_TABLE}` AS n
      ON c.subject_id = n.subject_id
     AND c.hadm_id = n.hadm_id
    WHERE (n.iserror IS NULL OR n.iserror = 0)
      AND n.charttime BETWEEN c.intime AND c.outtime
    """

    df_notes = client.query(query).to_dataframe()
    print("Notes shape:", df_notes.shape)
    print(df_notes.head())
    print(f"Loaded {len(df_notes)} notes")
    return df_notes


# -------------------------
# STEP 3: SEPSIS ONSET (TEXT KEYWORDS)
# -------------------------

SEPSIS_KEYWORDS = [
    "sepsis",
    "septicemia",
    "septic shock",
    "septicemia/sepsis",
    "shock",
    "hypotension refractory",
    "vasopressors",
    "pressors",
    "qSOFA",
    "bandemia",
    "SIRS",
    "infection suspected",
    "antibiotics started",
    "bacteremia",
    "urosepsis",
    "respiratory failure + infection",
    "fever + leukocytosis",
]


def compute_sepsis_onset_from_notes(df_notes: pd.DataFrame) -> pd.DataFrame:
    """
    Simple surrogate sepsis onset:
    earliest charttime where any SEPSIS_KEYWORDS appears in text.
    Grouping key: icustay_id.
    """
    print("Computing sepsis onset from notes (keyword-based surfrogate)...")

    if df_notes.empty:
        return pd.DataFrame(columns=["icustay_id", "sepsis_onset_time"])

    # Lowercase text once
    df = df_notes.copy()
    df["text_lower"] = df["text"].str.lower().fillna("")

    pattern = "|".join([re.escape(k.lower()) for k in SEPSIS_KEYWORDS])
    sepsis_mask = df["text_lower"].str.contains(pattern, regex=True)

    df_sepsis = df[sepsis_mask].copy()
    if df_sepsis.empty:
        print("No sepsis keywords found in notes.")
        return pd.DataFrame(columns=["icustay_id", "sepsis_onset_time"])

    # group by icustay_id, take earliest charttime
    onset = (
        df_sepsis.groupby("icustay_id", as_index=False)["charttime"]
        .min()
        .rename(columns={"charttime": "sepsis_onset_time"})
    )

    print(onset.head())
    return onset


# -------------------------
# STEP 4: BUILD 24H INPUT TEXT
# -------------------------

def format_single_note_row(row: pd.Series) -> str:
    """Format a single note row into a line for the prompt."""
    ts = row["charttime"]
    cat = row.get("category", "")
    txt = row.get("text", "") or ""
    # Collapse whitespace and trim
    txt = " ".join(str(txt).split())
    return f"[{ts}] ({cat}) {txt}"


def build_input_text_24h(df_notes: pd.DataFrame, cohort: pd.DataFrame) -> pd.DataFrame:
    """
    Build input text for first 24h after ICU admission.
    - Restrict notes: intime <= charttime <= intime + OBS_HOURS
    - Group by icustay_id
    - Produce a single string per icustay_id
    """
    print("Building input text from first 24h notes...")

    if df_notes.empty:
        print("No notes available at all; will fall back to 'No notes available.'")
        return pd.DataFrame(columns=["icustay_id", "input_text"])

    # Merge intime by icustay_id
    cohort_min = cohort[["icustay_id", "intime"]].drop_duplicates()
    notes = df_notes.merge(cohort_min, on="icustay_id", how="left", suffixes=("", "_icu"))

    # Compute 24h cutoff
    notes["cutoff_24h"] = notes["intime"] + pd.to_timedelta(OBS_HOURS, unit="h")

    # Filter to first 24h
    mask_24h = (notes["charttime"] >= notes["intime"]) & (
        notes["charttime"] <= notes["cutoff_24h"]
    )
    notes_24h = notes[mask_24h].copy()

    if notes_24h.empty:
        print("No notes within first 24h for any ICU stay.")
        return pd.DataFrame(columns=["icustay_id", "input_text"])

    notes_24h = notes_24h.sort_values(["icustay_id", "charttime"])

    def format_group(group: pd.DataFrame) -> str:
        lines = [format_single_note_row(r) for _, r in group.iterrows()]
        body = "\n".join(lines)
        header = (
            "You are a clinical model. Below are notes up to 24 hours after ICU admission.\n\n"
        )
        return header + body

    # groupby icustay_id
    df_inputs = (
        notes_24h.groupby("icustay_id", as_index=False)
        .apply(lambda g: pd.Series({"input_text": format_group(g)}))
    )

    print(df_inputs.head())
    return df_inputs[["icustay_id", "input_text"]]


# -------------------------
# STEP 5: MULTI-HORIZON LABELS
# -------------------------

def compute_labels_multi_horizon(
    cohort: pd.DataFrame,
    onset_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    For each ICU stay, compute multi-horizon sepsis labels.
    - t_cutoff = intime + OBS_HOURS
    - If sepsis_onset_time in (t_cutoff, t_cutoff + h] => label h = 1
    - Else 0
    - Accumulate forward (if h12=1 => h24=h48=1)
    """
    print("Computing multi-horizon labels...")

    df = cohort[["icustay_id", "intime"]].copy()
    df = df.merge(onset_df, on="icustay_id", how="left")

    # cutoff time
    df["t_cutoff"] = df["intime"] + pd.to_timedelta(OBS_HOURS, unit="h")

    # default labels
    for h in HORIZONS:
        df[f"h{h}"] = 0

    # compute offset hours where sepsis onset exists
    has_onset = df["sepsis_onset_time"].notna()

    # difference in hours
    df.loc[has_onset, "offset_hours"] = (
        (df.loc[has_onset, "sepsis_onset_time"] - df.loc[has_onset, "t_cutoff"])
        .dt.total_seconds()
        / 3600.0
    )

    # positive if within (0, 48]
    for idx, row in df[has_onset].iterrows():
        offset = row["offset_hours"]
        if offset is None or pd.isna(offset):
            continue
        if offset <= 0 or offset > max(HORIZONS):
            continue
        # assign labels with accumulation
        for h in HORIZONS:
            if offset <= h:
                df.at[idx, f"h{h}"] = 1

    print(df[["icustay_id", "sepsis_onset_time"] + [f"h{h}" for h in HORIZONS]].head())
    return df[["icustay_id", "t_cutoff"] + [f"h{h}" for h in HORIZONS]]


# -------------------------
# STEP 6: ASSEMBLE FINAL DATASET & WRITE JSONL
# -------------------------

@dataclass
class ExampleRecord:
    input: str
    output: Dict[str, Any]
    meta: Dict[str, Any]


def build_final_dataset(
    cohort: pd.DataFrame,
    inputs_df: pd.DataFrame,
    labels_df: pd.DataFrame,
    target: str = "sepsis",
) -> List[ExampleRecord]:
    """
    Merge cohort, input_text, and labels into final example records.
    """
    print("Assembling final dataset...")

    df = cohort[["subject_id", "hadm_id", "icustay_id"]].copy()

    # merge input_text
    df = df.merge(inputs_df, on="icustay_id", how="left")

    # fill no-note stays with default text
    default_input = (
        "You are a clinical model. Below are notes up to 24 hours after ICU admission.\n\n"
        "No notes available."
    )
    df["input_text"] = df["input_text"].fillna(default_input)

    # merge labels
    df = df.merge(labels_df, on="icustay_id", how="left")

    # any missing label rows => fill 0
    for h in HORIZONS:
        col = f"h{h}"
        df[col] = df[col].fillna(0).astype(int)

    df["t_cutoff"] = df["t_cutoff"].fillna(df["icustay_id"].map(
        cohort.set_index("icustay_id")["intime"]
    ) + pd.to_timedelta(OBS_HOURS, unit="h"))

    examples: List[ExampleRecord] = []
    for _, row in df.iterrows():
        output = {f"h{h}": int(row[f"h{h}"]) for h in HORIZONS}
        output["rationale"] = ""  # placeholder for future

        meta = {
            "icustay_id": int(row["icustay_id"]),
            "subject_id": int(row["subject_id"]),
            "hadm_id": int(row["hadm_id"]),
            "t_cutoff": OBS_HOURS,
            "target": target,
        }

        examples.append(
            ExampleRecord(
                input=row["input_text"],
                output=output,
                meta=meta,
            )
        )

    print(f"Built {len(examples)} examples")
    return examples


def write_jsonl(examples: List[ExampleRecord], output_path: str) -> None:
    """
    Write examples to JSONL in the desired format.
    """
    print(f"Writing JSONL dataset to {output_path}...")
    with open(output_path, "w", encoding="utf-8") as f:
        for ex in examples:
            rec = {
                "input": ex.input,
                "output": ex.output,
                "meta": ex.meta,
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"Wrote {len(examples)} records to {output_path}")


# -------------------------
# MAIN
# -------------------------

def main():
    client = get_bq_client()

    # 1) Cohort
    cohort = load_cohort_bq(client)

    # 2) Notes
    df_notes = load_notes_for_cohort_bq(client)

    # 3) Sepsis onset from notes
    onset_df = compute_sepsis_onset_from_notes(df_notes)

    # 4) Input text (24h)
    inputs_df = build_input_text_24h(df_notes, cohort)

    # 5) Labels
    labels_df = compute_labels_multi_horizon(cohort, onset_df)

    # 6) Final examples
    examples = build_final_dataset(cohort, inputs_df, labels_df, target="sepsis")

    # 7) Write JSONL
    write_jsonl(examples, OUTPUT_JSONL)


if __name__ == "__main__":
    main()
