WITH sofa AS (
    SELECT
        stay_id,
        starttime,
        endtime,
        respiration_24hours AS respiration,
        coagulation_24hours AS coagulation,
        liver_24hours AS liver,
        cardiovascular_24hours AS cardiovascular,
        cns_24hours AS cns,
        renal_24hours AS renal,
        sofa_24hours AS sofa_score
    FROM `physionet-data.mimiciv_derived.sofa`
    WHERE sofa_24hours >= 2
),

s1 AS (
    SELECT
        soi.subject_id,
        soi.stay_id,
        -- suspicion columns
        soi.ab_id,
        soi.antibiotic,
        soi.antibiotic_time,
        soi.culture_time,
        soi.suspected_infection,
        soi.suspected_infection_time,
        soi.specimen,
        soi.positive_culture,
        -- sofa columns
        starttime,
        endtime AS sofa_time,
        respiration,
        coagulation,
        liver,
        cardiovascular,
        cns,
        renal,
        sofa_score,
        -- Sepsis-3 flag
        (sofa_score >= 2 AND suspected_infection = 1) AS sepsis3,
        -- earliest relevant event per stay
        ROW_NUMBER() OVER (
            PARTITION BY soi.stay_id
            ORDER BY
                suspected_infection_time,
                antibiotic_time,
                culture_time,
                endtime
        ) AS rn_sus
    FROM `physionet-data.mimiciv_derived.suspicion_of_infection` AS soi
    INNER JOIN sofa
        ON soi.stay_id = sofa.stay_id
        AND sofa.endtime >= DATETIME_SUB(soi.suspected_infection_time, INTERVAL 48 HOUR)
        AND sofa.endtime <= DATETIME_ADD(soi.suspected_infection_time, INTERVAL 24 HOUR)
    WHERE soi.stay_id IS NOT NULL
),

sepsis3_onset AS (
    SELECT
        subject_id,
        stay_id,
        antibiotic_time,
        culture_time,
        suspected_infection_time,
        sofa_time,
        sofa_score,
        respiration,
        coagulation,
        liver,
        cardiovascular,
        cns,
        renal,
        sepsis3,
        -- define a single onset timestamp when sepsis3 is true
        CASE
            WHEN sepsis3 THEN GREATEST(suspected_infection_time, sofa_time)
            ELSE NULL
        END AS sepsis_onset_time
    FROM s1
    WHERE rn_sus = 1
)

SELECT
    subject_id,
    stay_id,
    sepsis3,
    sepsis_onset_time
FROM sepsis3_onset;
