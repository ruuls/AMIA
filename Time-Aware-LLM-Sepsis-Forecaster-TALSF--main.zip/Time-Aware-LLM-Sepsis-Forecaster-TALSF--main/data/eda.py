import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import textwrap

DATA_PATH = "sepsis_multihorizon_24h_notes_mimic3_bq.jsonl"


def load_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            rows.append({
                **obj["meta"],
                **obj["output"],
                "input_text": obj["input"]
            })
    return pd.DataFrame(rows)


def print_header(title):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80 + "\n")


def summarize_labels(df):
    print_header("MULTI-HORIZON LABEL DISTRIBUTION")

    cols = ["h6", "h12", "h24", "h48"]
    for c in cols:
        pos = df[c].sum()
        pct = 100 * pos / len(df)
        print(f"{c}: {pos} positive ({pct:.2f}%)")

    print("\nCo-occurrence matrix:")
    print(df[["h6","h12","h24","h48"]].corr())


def note_length_stats(df):
    print_header("NOTE LENGTH STATISTICS")

    df["char_len"] = df["input_text"].str.len()
    df["token_len"] = df["input_text"].str.split().str.len()

    print(df[["char_len", "token_len"]].describe())

    print("\nExample short note:")
    print(textwrap.fill(df.loc[df.char_len.idxmin(), "input_text"], width=80))

    print("\nExample long note:")
    print(textwrap.fill(df.loc[df.char_len.idxmax(), "input_text"][:1500], width=80))


def icu_stay_stats(df):
    print_header("ICU STAY COUNTS")

    n_patients = df["subject_id"].nunique()
    n_hadm = df["hadm_id"].nunique()
    n_stays = df["icustay_id"].nunique()

    print(f"Unique patients:      {n_patients}")
    print(f"Unique admissions:    {n_hadm}")
    print(f"Unique ICU stays:     {n_stays}")
    print(f"Total rows:           {len(df)}")


def plot_label_distribution(df):
    print_header("PLOTTING LABEL DISTRIBUTION")

    cols = ["h6","h12","h24","h48"]
    counts = df[cols].sum()

    plt.figure(figsize=(8,5))
    sns.barplot(x=counts.index, y=counts.values)
    plt.title("Label Counts per Horizon")
    plt.ylabel("Positive Count")
    plt.tight_layout()
    plt.show()


def plot_note_lengths(df):
    print_header("PLOTTING NOTE LENGTH DISTRIBUTION")

    plt.figure(figsize=(8,5))
    sns.histplot(df["token_len"], bins=60, log_scale=(False, True))
    plt.title("Distribution of Input Note Token Lengths")
    plt.xlabel("Token Count (log y-scale)")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.show()


def parse_note_timestamps(text):
    """Extract all timestamps from an input_text block.
    Timestamps are expected in the format: [YYYY-MM-DD HH:MM:SS]
    Returns list of pd.Timestamp (may be empty).
    """
    if not isinstance(text, str):
        return []
    # find patterns like [2020-01-01 12:34:56]
    import re

    pattern = r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]"
    matches = re.findall(pattern, text)
    if not matches:
        return []
    return pd.to_datetime(matches, errors="coerce").dropna().tolist()


def plot_notes_per_stay(df):
    print_header("PLOTTING NOTES PER STAY")

    # count number of note lines (lines starting with [timestamp])
    df["num_notes"] = df["input_text"].apply(lambda t: len(parse_note_timestamps(t)))

    plt.figure(figsize=(8,5))
    sns.histplot(df["num_notes"].clip(upper=50), bins=30)
    plt.title("Number of Notes per ICU Stay (clipped at 50)")
    plt.xlabel("Number of Notes")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.show()


def plot_time_span_distribution(df):
    print_header("PLOTTING NOTE TIME-SPAN PER STAY")

    def span_hours(text):
        ts = parse_note_timestamps(text)
        if len(ts) == 0:
            return np.nan
        return (max(ts) - min(ts)).total_seconds() / 3600.0

    df["span_hours"] = df["input_text"].apply(span_hours)

    plt.figure(figsize=(8,5))
    sns.histplot(df["span_hours"].dropna().clip(upper=48), bins=40)
    plt.title("Distribution of Time Span Covered by Notes (hours, clipped at 48)")
    plt.xlabel("Span (hours)")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.show()


def plot_label_vs_note_presence(df):
    print_header("LABEL BALANCE: NOTE PRESENCE VS NO-NOTES")

    df["has_notes"] = ~df["input_text"].str.contains("No notes available")
    cols = ["h6","h12","h24","h48"]

    summary = []
    for c in cols:
        pos_with_notes = df.loc[df["has_notes"], c].sum()
        n_with = df["has_notes"].sum()
        pos_no_notes = df.loc[~df["has_notes"], c].sum()
        n_no = (~df["has_notes"]).sum()
        summary.append({"horizon": c, "with_notes_pct": 100 * pos_with_notes / max(1, n_with), "no_notes_pct": 100 * pos_no_notes / max(1, n_no)})

    summ_df = pd.DataFrame(summary).set_index("horizon")

    summ_df.plot.bar(figsize=(8,5))
    plt.title("% Positive by Horizon: With Notes vs No Notes")
    plt.ylabel("% Positive")
    plt.tight_layout()
    plt.show()


def plot_token_length_by_label(df):
    print_header("TOKEN LENGTH BY H24 LABEL")

    plt.figure(figsize=(8,5))
    sns.boxplot(x=df["h24"].astype(str), y=df["token_len"].clip(upper=2000))
    plt.title("Token Length Distribution by h24 Label (0 vs 1)")
    plt.xlabel("h24 label")
    plt.ylabel("Token Length (clipped)")
    plt.tight_layout()
    plt.show()


def plot_horizon_heatmap(df):
    print_header("HORIZON CO-OCCURRENCE HEATMAP")

    cols = ["h6","h12","h24","h48"]
    corr = df[cols].corr()
    plt.figure(figsize=(6,5))
    sns.heatmap(corr, annot=True, cmap="vlag", vmin=-1, vmax=1)
    plt.title("Correlation between horizon labels")
    plt.tight_layout()
    plt.show()


def inspect_positive_cases(df, horizon="h24", n=3):
    print_header(f"RANDOM POSITIVE EXAMPLES: {horizon.upper()}")

    pos = df[df[horizon] == 1].sample(min(n, len(df[df[horizon]==1])))

    for idx, row in pos.iterrows():
        print(f"\n--- Example (icustay_id={row['icustay_id']}) ---")
        print(textwrap.fill(row["input_text"][:1500], width=80))


def inspect_no_note_cases(df, n=5):
    print_header("EXAMPLES WITH NO NOTES IN FIRST 24h")

    subset = df[df["input_text"].str.contains("No notes available")].sample(n)
    for idx, row in subset.iterrows():
        print(f"- icustay_id: {row['icustay_id']}, labels: {row[['h6','h12','h24','h48']].to_dict()}")


def main():
    print_header("LOADING DATA")
    df = load_jsonl(DATA_PATH)
    print(f"Loaded {len(df)} rows")

    icu_stay_stats(df)
    summarize_labels(df)
    note_length_stats(df)
    inspect_no_note_cases(df, n=5)

    # Visualizations
    plot_label_distribution(df)
    plot_note_lengths(df)

    inspect_positive_cases(df, "h24", n=3)
    inspect_positive_cases(df, "h48", n=3)


if __name__ == "__main__":
    main()
