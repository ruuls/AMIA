from google.cloud import bigquery
import pandas as pd

GCP_PROJECT_ID = "charged-sector-450700-m8"

def main():
    client = bigquery.Client(project=GCP_PROJECT_ID)

    query = """
    SELECT
      subject_id,
      stay_id,
      hadm_id,
      intime,
      outtime
    FROM `physionet-data.mimiciv_3_1_icu.icustays`
    LIMIT 5
    """

    df = client.query(query).to_dataframe()
    print(df)

if __name__ == "__main__":
    main()
