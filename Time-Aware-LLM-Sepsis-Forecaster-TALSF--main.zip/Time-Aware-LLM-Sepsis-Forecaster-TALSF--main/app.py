import json
import io
import pandas as pd
import streamlit as st

# -------------------------
# Page config
# -------------------------
st.set_page_config(
    page_title="Sepsis Multi-Horizon JSONL Viewer",
    layout="wide",
)

st.title("Sepsis Multi-Horizon Notes Dataset Viewer")


@st.cache_data(show_spinner=True)
def load_jsonl_to_df(file_bytes) -> pd.DataFrame:
    """
    Load JSONL bytes into a pandas DataFrame with flattened keys.
    This does not impose any artificial size limit other than
    the max_rows argument and what the browser uploader can handle.
    """
    rows = []
    buffer = io.StringIO(file_bytes.decode("utf-8", errors="ignore"))
    for i, line in enumerate(buffer):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        rows.append(obj)

    if not rows:
        return pd.DataFrame()

    df = pd.json_normalize(rows)
    return df


def get_col(df: pd.DataFrame, candidates):
    """
    Return the first existing column name from candidates, or None.
    """
    for c in candidates:
        if c in df.columns:
            return c
    return None


def df_to_jsonl(df: pd.DataFrame) -> str:
    """
    Convert a flattened df back into JSONL string, rebuilding nested
    'output' and 'meta' if present.
    """
    lines = []
    for _, row in df.iterrows():
        obj = {}

        # input
        if "input" in df.columns:
            obj["input"] = row["input"]

        # rebuild output
        output = {}
        for key in ["h6", "h12", "h24", "h48", "rationale"]:
            col = f"output.{key}"
            if col in df.columns and pd.notna(row[col]):
                output[key] = row[col]
        if output:
            obj["output"] = output

        # rebuild meta from meta.* columns
        meta = {}
        for col in df.columns:
            if col.startswith("meta."):
                short = col.split("meta.", 1)[1]
                meta[short] = row[col]
        if meta:
            obj["meta"] = meta

        # fallback if meta.* not present but flat columns are
        if "meta" not in obj:
            flat_keys = ["icustay_id", "stay_id", "hadm_id", "subject_id", "t_cutoff", "target"]
            for k in flat_keys:
                if k in df.columns and pd.notna(row[k]):
                    meta.setdefault(k, row[k])
            if meta:
                obj["meta"] = meta

        lines.append(json.dumps(obj))

    return "\n".join(lines)


# -------------------------
# Sidebar: file + options
# -------------------------

st.sidebar.header("1. Load JSONL file")

uploaded_file = st.sidebar.file_uploader(
    "Upload JSONL dataset", type=["jsonl"]
)

max_rows = st.sidebar.number_input(
    "Max rows to load (for speed)",
    min_value=10,
    max_value=500000,
    value=50000,
    step=10,
)

if uploaded_file is None:
    st.info("⬅️ Upload a `.jsonl` file in the sidebar to begin.")
    st.stop()

with st.spinner("Loading JSONL into memory..."):
    df = load_jsonl_to_df(uploaded_file.getvalue())

    if df.empty:
        st.error("Loaded file appears to be empty or invalid JSONL.")
        st.stop()

    # Optionally truncate to max_rows for speed
    if len(df) > max_rows:
        df = df.head(max_rows)

    st.success(f"Loaded {len(df):,} rows from JSONL.")

# -------------------------
# Identify core columns
# -------------------------

input_col = get_col(df, ["input"])

h6_col = get_col(df, ["output.h6", "h6"])
h12_col = get_col(df, ["output.h12", "h12"])
h24_col = get_col(df, ["output.h24", "h24"])
h48_col = get_col(df, ["output.h48", "h48"])
rationale_col = get_col(df, ["output.rationale", "rationale"])

icustay_col = get_col(df, ["meta.icustay_id", "meta.stay_id", "stay_id", "icustay_id"])
subject_col = get_col(df, ["meta.subject_id", "subject_id"])
hadm_col = get_col(df, ["meta.hadm_id", "hadm_id"])
tcut_col = get_col(df, ["meta.t_cutoff", "t_cutoff"])
target_col = get_col(df, ["meta.target", "target"])

label_cols = [c for c in [h6_col, h12_col, h24_col, h48_col] if c is not None]

# -------------------------
# Sidebar: filters
# -------------------------

st.sidebar.subheader("Filter by label(s)")

label_filter = {}
for col, name in [
    (h6_col, "h6 (0–6h)"),
    (h12_col, "h12 (0–12h)"),
    (h24_col, "h24 (0–24h)"),
    (h48_col, "h48 (0–48h)"),
]:
    if col is None:
        continue
    val = st.sidebar.selectbox(
        f"{name}",
        options=["Any", "Positive (1)", "Negative (0)"],
        index=0,
        key=f"filter_{col}",
    )
    label_filter[col] = val

# ID filters
subject_filter = st.sidebar.text_input(
    "Filter by subject_id (exact or comma-separated)", ""
)
icustay_filter = st.sidebar.text_input(
    "Filter by icustay_id/stay_id (exact or comma-separated)", ""
)

# Text search
search_text = st.sidebar.text_input(
    "Search in notes (case-insensitive)", ""
)

max_display_rows = st.sidebar.slider(
    "Max rows to display in list",
    min_value=10,
    max_value=200,
    value=50,
    step=10,
)

# -------------------------
# Apply filters
# -------------------------

filtered = df.copy()

# Label filter
for col, choice in label_filter.items():
    if col is None:
        continue
    if choice == "Positive (1)":
        filtered = filtered[filtered[col] == 1]
    elif choice == "Negative (0)":
        filtered = filtered[filtered[col] == 0]

# subject filter
if subject_filter.strip() and subject_col is not None:
    wanted_subjects = {
        int(x.strip())
        for x in subject_filter.split(",")
        if x.strip().isdigit()
    }
    if wanted_subjects:
        filtered = filtered[filtered[subject_col].isin(wanted_subjects)]

# icustay filter
if icustay_filter.strip() and icustay_col is not None:
    wanted_stays = {
        int(x.strip())
        for x in icustay_filter.split(",")
        if x.strip().isdigit()
    }
    if wanted_stays:
        filtered = filtered[filtered[icustay_col].isin(wanted_stays)]

# text search
if search_text.strip() and input_col is not None:
    pattern = search_text.strip().lower()
    filtered = filtered[
        filtered[input_col].str.lower().str.contains(pattern, na=False)
    ]

# -------------------------
# Summary / EDA
# -------------------------

st.subheader("Label distribution (on filtered subset)")

if label_cols:
    label_means = filtered[label_cols].mean().rename(
        lambda x: x.replace("output.", "")
    )

    st.bar_chart(label_means)
    st.write(label_means.to_frame("Positive rate").style.format("{:.3f}"))
else:
    st.info("No label columns detected (output.h6/h12/h24/h48).")

# -------------------------
# Download filtered subset
# -------------------------

st.subheader("Download filtered subset")

col_dl1, col_dl2 = st.columns(2)

with col_dl1:
    csv_data = filtered.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="⬇️ Download CSV",
        data=csv_data,
        file_name="filtered_sepsis_subset.csv",
        mime="text/csv",
    )

with col_dl2:
    # best-effort JSONL reconstruction
    jsonl_str = df_to_jsonl(filtered)
    st.download_button(
        label="⬇️ Download JSONL",
        data=jsonl_str.encode("utf-8"),
        file_name="filtered_sepsis_subset.jsonl",
        mime="application/json",
    )

# -------------------------
# Tabbed main view
# -------------------------

tab1, tab2 = st.tabs(["📋 Samples", "📊 Table View"])

# ---------- Tab 1: Samples with expanders ----------
with tab1:
    if input_col is None:
        st.error("No `input` column found in JSONL. Cannot render note text.")
    else:
        subset = filtered.head(max_display_rows)

        if subset.empty:
            st.warning("No rows match the current filters.")
        else:
            for idx, row in subset.iterrows():
                icu_val = row.get(icustay_col, "N/A") if icustay_col else "N/A"
                subj_val = row.get(subject_col, "N/A") if subject_col else "N/A"
                hadm_val = row.get(hadm_col, "N/A") if hadm_col else "N/A"
                cutoff_val = row.get(tcut_col, "N/A") if tcut_col else "N/A"

                label_str_parts = []
                if h6_col:
                    label_str_parts.append(f"h6={row[h6_col]}")
                if h12_col:
                    label_str_parts.append(f"h12={row[h12_col]}")
                if h24_col:
                    label_str_parts.append(f"h24={row[h24_col]}")
                if h48_col:
                    label_str_parts.append(f"h48={row[h48_col]}")
                label_str = ", ".join(label_str_parts)

                header = (
                    f"Row {idx} | ICU stay: {icu_val} | Subject: {subj_val} "
                    f"| HADM: {hadm_val} | t_cutoff={cutoff_val}h | {label_str}"
                )

                with st.expander(header, expanded=False):
                    st.markdown("**Input (notes up to cutoff)**")
                    st.code(row[input_col], language="text")

                    if (
                        rationale_col
                        and isinstance(row.get(rationale_col), str)
                        and row[rationale_col]
                    ):
                        st.markdown("**Rationale**")
                        st.write(row[rationale_col])

                    st.markdown("**Meta**")
                    meta_info = {}
                    for col in df.columns:
                        if col.startswith("meta."):
                            meta_info[col] = row.get(col)
                    if not meta_info:
                        meta_info = {
                            "icustay_id": icu_val,
                            "subject_id": subj_val,
                            "hadm_id": hadm_val,
                            "t_cutoff": cutoff_val,
                            "target": row.get(target_col, "sepsis")
                            if target_col
                            else "sepsis",
                        }
                    st.json(meta_info)

# ---------- Tab 2: Table view ----------
with tab2:
    display_df = filtered.copy()

    # shorten input for readability
    if input_col in display_df.columns:
        display_df["input_preview"] = display_df[input_col].str.slice(0, 200)
        cols_to_show = [c for c in display_df.columns if c != input_col]
    else:
        cols_to_show = display_df.columns.tolist()

    st.dataframe(display_df[cols_to_show].head(max_display_rows))
